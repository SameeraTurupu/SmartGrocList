import datetime

#apriori
import numpy as np
import pandas as pd
from apyori import apriori


# load data
purchase_data = pd.read_csv('/Users/umarajpotla/Desktop/pearlhack/SmartGrocList/purchaseDetails1.csv')
purchase_data.head()

purchase_data.shape

#converting pandas dataframe to list of lists
records = []
for i in range(0,30):
    records.append([str(purchase_data.values[i,j]) for j in range(3,7)])
records

# building apriori model
association_rules = apriori(records, min_support=0.0050, min_confidence=0.6, min_lift=2, min_length=2,max_length=None)
associationResult = list(association_rules)

# print association rules
print(associationResult)


suggestions = [x for x in associationResult[0][0]]
print(suggestions)

df = pd.DataFrame(suggestions, columns=["suggestions"])
df.to_csv('suggestionListText.txt', index=False)
